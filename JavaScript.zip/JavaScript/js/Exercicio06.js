function executarExercicio06(){

    alert("Escreva um algoritmo para ler as dimensões de um retângulo (base e altura), calcular e escrever a área do retângulo.")
var base = parseInt(prompt("Digite a base do retângulo"))
var altura = parseInt(prompt("Digite a altura do retângulo"))

var areaRetangulo = base * altura

alert("A área do retângulo é: "+areaRetangulo+"m²")
}