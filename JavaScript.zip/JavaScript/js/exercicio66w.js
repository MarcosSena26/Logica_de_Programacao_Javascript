function executarExercicio66w(){
    alert(`Exercicio 66)\nFaça um programa que exiba os números de 1 a 10.`)

    for (let contadora = 1; contadora <= 10; contadora++) {
        alert(contadora);
    }
}