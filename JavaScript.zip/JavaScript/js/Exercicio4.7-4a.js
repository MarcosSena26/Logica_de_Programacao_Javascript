function executarExercicio474a(){
    
    alert("Ler dois valores numéricos inteiros e apresentar o resultado da diferença do maior pelo menor valor. ")
let valor1 = parseInt(prompt("Digite o primeiro valor: "))
let valor2 = parseInt(prompt("Digite o segundo valor: "))

if (valor1 > valor2){
    alert("O valor da diferença é: "+(valor1-valor2))
}






}