function executarExercicio68w() {
    alert(`Exercicio 68)\nCrie um programa que exiba os números pares de 1 a 50.`)

    for (let contadora = 1; contadora < 51; contadora++) {
        if (contadora % 2 == 0){
            alert(contadora)
        }
    }
}