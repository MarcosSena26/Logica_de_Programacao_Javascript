function executarExercicio51w() {
    alert(`Exercicio 51)\nFaça um programa que exiba os números de 1 a 10 usando o loop "do-while".`)

    let numero = 1

    do{
    alert(numero)
    numero++
    }while (numero <= 10) 
    //numero = numero+1
    //numero +=1
}