function executarExercicio77w(){
    alert(`Exercicio 77)\nCrie um programa que exiba os números ímpares de 50 a 1.`)

    for (let contadora = 1; contadora < 50; contadora++) {
        if(contadora%2!=0){
            alert(contadora)
        }        
    }
}