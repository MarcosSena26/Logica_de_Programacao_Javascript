function executarExercicio14(){

    alert("Ler um valor e escrever a mensagem É MAIOR QUE 10! se o valor lido for maior que 10, caso contrário escrever NÃO É MAIOR QUE 10! ")

    let valor = parseFloat(prompt("Digite um valor:"))
     if (valor >=10) {
        alert("O valor digitado é maior que 10.")
     }
     else if (valor < 10) {
        alert("O valor digitado é menor que 10.")
     }

}