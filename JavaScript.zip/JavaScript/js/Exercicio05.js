function executarExercicio05(){



alert("Escreva um algoritmo para ler um valor (do teclado) e escrever (na tela) o seu antecessor. ")

var valor = parseInt(prompt("Digite o valor: "))
var antecessor = valor - 1

alert("O antecessor de"+valor+" é: "+antecessor)
//alert(antecessor)
}