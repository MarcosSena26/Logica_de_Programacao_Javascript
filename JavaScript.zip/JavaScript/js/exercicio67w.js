function executarExercicio67w() {
    alert(`Exercicio 67)\nEscreva um programa que calcule a soma dos números de 1 a 100.`)


    let acumuladora = 0
    for (let contadora = 0; contadora < 101; contadora++) {
        acumuladora = acumuladora + contadora
    }
    alert(acumuladora)
}