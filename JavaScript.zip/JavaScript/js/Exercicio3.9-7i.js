function executarExercicioi(){
alert("Ler dois inteiros (variáveis A e B) e imprimir o resultado do quadrado da diferença do primeiro valor pelo segundo. ")

let a =  parseInt(prompt("Digite o valor de A: "))
let b =  parseInt(prompt("Digite o valor de B: "))
let c = (a-b)**2

alert("O quadrado da diferença é: "+c)

}
