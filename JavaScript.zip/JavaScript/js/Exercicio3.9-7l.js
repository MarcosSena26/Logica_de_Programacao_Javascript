function executarExerciciol(){
    alert("l)	Elaborar um programa que efetue a leitura de três valores (A, B e C) e apresente como resultado final à soma dos quadrados dos três valores lidos. ")

    let a =  parseFloat(prompt("Digite o valor de A: "))
    let b =  parseFloat(prompt("Digite o valor de B: "))
    let c =  parseFloat(prompt("Digite o valor de B: "))

    let quadrado = (a**a) + (b**b) + (c**c)

    alert("A soma do quadrado dos três valores informados é: "+quadrado)






}