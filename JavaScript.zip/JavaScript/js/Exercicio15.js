function executarExercicio15(){
alert("Ler um valor e escrever se é positivo ou negativo (considere o valor zero como positivo). ")

let valor = parseFloat(prompt("Digite um valor:"))

if (valor >= 0){
    alert("O valor digitado é positivo.")
}
else if (valor <0){
    alert("o valor digitado é negativo.")
}

}