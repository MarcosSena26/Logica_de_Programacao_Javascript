function executarExercicio36w(){
    alert(`Exercicio 36)\nFaça um programa que exiba os números de 1 a 10 usando o loop "while".`)
    
    let numero = 1

    while (numero <= 10) {
        alert(numero)
        numero++
        //numero = numero+1
        //numero +=1
    }
}