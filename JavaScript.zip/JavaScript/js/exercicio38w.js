function executarExercicio38w() {
    alert(`Exercicio 38)\nCrie um programa que exiba os números pares de 1 a 50 usando o loop "while".`)

    let contadora = 0

    while (contadora < 52) {
        if (contadora % 2 == 0) {
            alert(contadora)
        }
        contadora++
    }
}