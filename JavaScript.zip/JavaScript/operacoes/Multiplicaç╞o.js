alert("Equipe 02 PROA")
alert("Multiplicação")


var numero=parseInt(prompt("Digite um número:"))
var numero2=parseInt(prompt("Digite um número:"))

var multi=numero*numero2

alert("A multiplicação dos valores corresponde a :"+multi)