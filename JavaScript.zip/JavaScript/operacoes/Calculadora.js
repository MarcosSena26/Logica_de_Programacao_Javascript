alert("Programa Calculadora")

alert("Soma")
var numero1=parseInt(prompt("Digite um número:"))
var numero2=parseInt(prompt("Digite outro número:"))
var soma=numero1+numero2
alert("O resultado da soma é:"+soma)

alert("Subtração")
var numero3=parseInt(prompt("Digite um número:"))
var numero4=parseInt(prompt("Digite outro número:"))
var subtracao=numero1-numero2
alert("O resultado da subtração é:"+subtracao)

alert("Divisão")
var numero5=parseInt(prompt("Digite um número:"))
var numero6=parseInt(prompt("Digite outro número:"))
var divisao=numero1/numero2
alert("O resultado da divisão é:"+divisao)

alert("Multiplicação")
var numero7=parseInt(prompt("Digite um número:"))
var numero8=parseInt(prompt("Digite outro número:"))
var multi=numero1*numero2
alert("O resultado da multiplicação é:"+multi)

