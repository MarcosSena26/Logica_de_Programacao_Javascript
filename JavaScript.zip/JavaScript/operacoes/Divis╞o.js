alert("Equipe 02 PROA")
alert("Divisão")


var numero=parseInt(prompt("Digite um número:"))
var numero2=parseInt(prompt("Digite um número:"))

var divisao=numero/numero2

alert("A divisão dos valores corresponde a :"+divisao)