alert("Equipe 02 PROA")
alert("Subtração")


var numero=parseInt(prompt("Digite um número:"))
var numero2=parseInt(prompt("Digite um número:"))

var subtracao=numero-numero2

alert("A subtração dos valores corresponde a :"+subtracao)