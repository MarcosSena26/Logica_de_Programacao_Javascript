alert("Equipe 02 PROA")
alert("Bom dia!")


var numero=parseInt(prompt("Digite um número:"))
var numero2=parseInt(prompt("Digite um número:"))

var soma=numero+numero2

alert("A soma dos valores corresponde a :"+soma)